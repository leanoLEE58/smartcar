#include "control.h"
#define HALL_PIN P26    //�������
uint8 flag_L_circ_pre=0, flag_L_circ_in=0, flag_L_circ_out=1, flag_L_circ_frc=0,flag_L_circ_frc_out=0; // �󻷵�
uint8 flag_R_circ_pre=0, flag_R_circ_in=0, flag_R_circ_out=1, flag_R_circ_frc=0,flag_R_circ_frc_out=0; // �һ���
float Angle_circ=0, Angle_block=0,Angle_zhi=0, Angle_stop=0, Angle_fork= 0,Angle_dun=0;    //����Ԫ�ص�ƫ��
uint8 flag_block_detected=0, flag_block_back=0, flag_block_adjust= 0,flag_HALL_detected=0;   //����
uint8 flag_L_zhi_in=0, flag_L_zhi_out=0, flag_L_zhi_frc=0; // ��ֱ��
uint8  flag_R_zhi_in=0, flag_R_zhi_out=0, flag_R_zhi_frc=0;//��ֱ��
uint8 flag_L_dun_in=0, flag_L_dun_out=0, flag_L_dun_frc=0; // ��ֱ��
uint8  flag_R_dun_in=0, flag_R_dun_out=0, flag_R_dun_frc=0;//��ֱ��
uint8 flag_L_speed_frc=0,flag_R_speed_frc=0;
uint8 flag_L_zhi_dun;
uint8 fang=0;
uint8 circ=0;    //1��ʱ���ʾ�ڶ�Բ���⴦����ֱ��ʹ�ô�ʱ��speed
uint8 flag_others = 0;    //�ж��Ƿ���ֱ��
uint8 flag_stop = 0;      //�Ƿ���ͣ��״̬

/***********************�ж��Ƿ�����ж�*************************
��������led_blink()
��  �ܣ��ж��Ƿ�����жϣ����ڵ��ԣ���ֹ�жϱ�
��  ������
����ֵ��void
*************************************************************/
void led_blink()
{
    static uint16 count_led = 0;
    count_led++;
    if(count_led >= 10)
    {
        count_led = 0;
        P52 = !P52; ; // ���ڵ��ԣ���ֹ�жϱ�    0.5 * TIM1_ISR_F
    }	
}
/***********************���ٶȵ�ʶ��*************************
��������void speed_choose()
��  �ܣ��ڼ����������ʱ�����м���
��  ������
����ֵ��void
//*************************************************************/
void speed_choose()
{
    if(!flag_others &&left_data<45&&right_data<55&&left_dataL>10&&right_dataR>5&&left_dataL>right_dataR) // &&left_data<70&&right_data<30
    {
			  flag_L_speed_frc = 1;	
		}
    if(!flag_others &&left_data<50&&right_data<40&&left_dataL>7&&right_dataR>10&&left_dataL<right_dataR) // &&left_data<70&&
    {
			 flag_R_speed_frc = 1;
	  }
}
/***********************��Բ����ʶ��*************************
��������void circ_recognition()
��  �ܣ���Բ������ʶ��
��  ������
����ֵ��void
//*************************************************************/
//void circ_recognition()
//{//
////    if(!flag_others && !flag_L_circ_in && left_dataL1 > 300 && left_data1 > 2500 && right_data1 > 2000)
//       // flag_L_circ_pre= 1;
//    //if(right_dataR1 > 300 && left_data1 > 2000 && right_data1 > 2500)
//			
//		if(!flag_others && !flag_R_circ_in && right_dataR1 > 300 && left_data1 > 2000 && right_data1 > 3000&&left_dataL1>60)  
//        flag_R_circ_pre= 1;
//}
void circ_recognition()
{
    if(!flag_others && !flag_L_circ_in && left_data+right_data>130&&right_dataR<10&&left_dataL>20&&left_dataL>right_dataR)//&& left_dataL> 40    &&left_data_X<10&&right_data_X>10
        flag_L_circ_pre= 1;    
			 
		if(!flag_others && !flag_R_circ_in && left_data+right_data>120&&left_dataL<10&&right_dataR>20&&left_dataL<right_dataR)  //&&  right_dataR>40     &&left_data1_X<30    &&left_data_X<5&&right_data_X>20
        flag_R_circ_pre= 1;
}
/***********************ֱ�Ǽ��*******************************
��������void zhijiao_recognition()
��  �ܣ���ֱ�Ǽ��
��  ������
����ֵ��void
*************************************************************/
//void zhijiao_recognition()
//{
//    if(flag_others==0 &&flag_R_circ_frc==0 &&left_dataL1 > 900&&(left_data1+right_data1 < 3200  )&&right_dataR1<650) //
//        flag_L_zhi_frc = 1;
//		
//    if(flag_others==0 &&flag_R_circ_frc==0 &&right_dataR1 > 900 &&(left_data1+right_data1 < 3200 ) &&left_dataL1<650)   //
//        flag_R_zhi_frc = 1;
//}(heng_chabih >-70||heng_chabih<70)&&left_dataL >60&&left_data+right_data<120&&left_dataL>2* right_dataR 
void zhijiao_recognition()
{
    if(flag_others==0 &&flag_L_circ_in==0&&left_data<45&&right_data<55&&left_dataL>10&&right_dataR>5&&left_dataL>right_dataR) // &&left_data<70&&right_data<30
    {
			  flag_L_zhi_frc = 1;	
		}
    if(flag_others==0 &&flag_R_circ_in==0 &&left_data<50&&right_data<40&&left_dataL>7&&right_dataR>10&&left_dataL<right_dataR) // &&left_data<70&&
    {
			 flag_R_zhi_frc = 1;
	  }
}
//	void zhijiao_recognition()
//{
//    if(flag_others==0 &&flag_L_circ_in==0 &&(heng_chabih >-70||heng_chabih<70)&&left_dataL >60&&left_data+right_data<120&&left_dataL>2* right_dataR ) // &&left_data<70&&right_data<30
//    {
//			  flag_L_zhi_frc = 1;	
//		}
//    if(flag_others==0 &&flag_R_circ_in==0 &&(heng_chabih >-70||heng_chabih<70)&& right_dataR>60&&left_data+right_data<120&&left_dataL*2<right_dataR)  // &&&&right_data<70
//    {
//			 flag_R_zhi_frc = 1;
//	  }
//}
/***********************120�ȽǼ��*******************************
��������void zhijiao_recognition()
��  �ܣ���ֱ�Ǽ��
��  ������
����ֵ��void
*************************************************************/
void dunjiao_recognition()
//{
//    if(flag_others==0&& left_dataL1 > 700&& right_dataR1 <350&&left_data1 >850&& right_data1 < 650  )
//        flag_L_dun_frc = 1;
//		
//    if(flag_others==0&&right_dataR1 > 700 && left_dataL1 <350 && left_data1 < 650&& right_data1 >850)
//        flag_R_dun_frc = 1;
//}
{
     if(flag_others==0 &&flag_L_circ_in==0&&left_data<60&&right_data<20&&left_data>right_dataR&&left_dataL>45&&right_dataR>12&&left_dataL>right_dataR) // &&left_data<70&&right_data<30
    {
			  flag_L_dun_frc = 1;
		}
    if(flag_others==0 &&flag_L_circ_in==0&&left_data<20&&right_data<60&&left_data<right_dataR&&left_dataL>12&&right_dataR>45&&left_dataL>right_dataR) // &&left_data<70&&
    {
			  flag_R_dun_frc = 1;
	  }
}

/***********************�ϰ�����****************************
��������void block_recognition()
��  �ܣ����ϰ�����м��
��  ������
����ֵ��void
*************************************************************/
void block_recognition()
{
    if((!flag_others) && dl1b_distance_mm < 700&&(!fang))
        flag_block_detected = 1; // ��⵽�ϰ���
}
/***********************ͣ�����****************************
��������void HALL_recognition()
��  �ܣ����ϰ�����м��
��  ������
����ֵ��void
*************************************************************/
void HALL_recognition()
{
    if(HALL_PIN == 0)
        flag_HALL_detected = 1; // ��⵽����
}
/***********************Բ������****************************
��������void circ_handler()
��  �ܣ���Բ�����м��
��  ������
����ֵ��void
*************************************************************/
void circ_handler()
{
	  float change_y=0;
    if(flag_L_circ_pre) // ԤԲ���׶�
    {
        flag_others = 1;
        //count_delay_L_circ_pre++;
        if(left_dataL+right_dataR<30&&left_data+right_data>170) //
        {
            flag_L_circ_pre = 0;     //Ҫ��
            flag_L_circ_frc = 1; 
        }
    }
	  if(flag_R_circ_pre) // ԤԲ���׶�
    {
			  circ=1;
        flag_others = 1;
        if(left_dataL+right_dataR<25&&left_data+right_data>180) //
        {
            flag_R_circ_pre = 0;
            flag_R_circ_frc = 1; // force to get into circ
        }
				else
				{
				    left_pwm = 1.5 * speed_rate * speed_goal;
            right_pwm = 1.5 * speed_rate * speed_goal;
				}
    }
    if(flag_L_circ_frc)
    {
			  circ=1;
        Angle_circ += imu660ra_gyro_z * 0.004 / 65.6;
        if(Angle_circ > 45  )
        {
            flag_L_circ_frc = 0;
            flag_L_circ_in = 1;
            flag_L_circ_out = 0;
        }
        else
        {
            left_pwm = 0.5 * speed_rate * speed_goal;
            right_pwm = 2 * speed_rate * speed_goal;
        }

    }
	if(flag_R_circ_frc)
    {
        Angle_circ += imu660ra_gyro_z * 0.004 / 65.6;		  
        if(Angle_circ< -15)
        {
            flag_R_circ_frc = 0;
            flag_R_circ_in = 1;
            flag_R_circ_out = 0;
//					  circ=0;
        }
        else
        {
            left_pwm = 1.5 * speed_rate * speed_goal;
            right_pwm = 0.5 * speed_rate * speed_goal;
        }

    }
    if(flag_L_circ_in)
    {
        Angle_circ += imu660ra_gyro_z * 0.004 / 65.6;
        if(Angle_circ >= 30)
        {
					flag_L_circ_in = 0;
          flag_others = 0;
					circ=0;
				}
//				else 
//				{
// 					  left_pwm = -1 * speed_rate * speed_goal;
//            right_pwm = 2 * speed_rate * speed_goal;
//				}
    }
	 if(flag_R_circ_in)
    {
        Angle_circ += imu660ra_gyro_z * 0.004 / 65.6;      
				if(Angle_circ <= -20 )
				{
					flag_R_circ_in = 0;
					flag_others = 0;
					circ=0;
				}
				else
				{
					left_pwm = 2 * speed_rate * speed_goal;
					right_pwm = -1* speed_rate * speed_goal;
				}									
    }
		

    if(flag_L_circ_in == 0 && flag_L_circ_out == 0)//right_dataR>2*left_dataL&&left_dataL>60  &&Angle_circ>350
    {
        Angle_circ += imu660ra_gyro_z * 0.004 / 65.6;			  
        if(left_dataL+right_dataR>30&&left_data+right_data>130)  //&&left_data_X+right_data_X>20
        {   
//					circ=1;
            flag_L_circ_out = 1; // �ѳ���
            Angle_circ = 0;
//					  flag_others = 0;
//					  circ=0;
        }
				else
				{
//				    left_pwm = -1 * speed_rate * speed_goal;
//            right_pwm = 2 * speed_rate * speed_goal;
				}
    }
	if(flag_R_circ_in == 0 && flag_R_circ_out == 0)//left_dataL>2*right_dataR&&right_dataR>60&&Angle_circ<-350
    {
        Angle_circ += imu660ra_gyro_z * 0.004 / 65.6;
        if(Angle_circ<-250)
        { 
					  if(left_dataL+right_dataR>40&&left_data+right_data>130)//&&left_data_X+right_data_X>20
				   	{
     			circ=1;
//					change_y=PlacePID_Control(&curve_PID,shu_chabihe,0);       //�ǶȻ����⻷��
//					left_pwm = speed_goal-change_y;
//          right_pwm = speed_goal+change_y;
            if(Angle_circ<-260)
						{
						  
            flag_R_circ_out = 1; // �ѳ���
            Angle_circ = 0;
						circ=0;
						}
						else
            {
						
//						   left_pwm = 0 * speed_rate * speed_goal;
//               right_pwm = 0 * speed_rate * speed_goal;
						}				
					}
        }
    }
}

/***********************ֱ�Ǵ���*************************
��������void zhijiao_handler()
��  �ܣ���ֱ�Ǵ���
��  ������
����ֵ��void
*************************************************************/
void zhijiao_handler()
{
    static uint16 count_delay_zhi; 
    if(flag_L_zhi_frc)
    {
			  flag_others=1;
        Angle_zhi += imu660ra_gyro_z * timer11 / 65.6;
        if(Angle_zhi >60)
        {
            flag_L_zhi_frc = 0;
            flag_others = 0;
					  Angle_zhi=0;
        }
        else
        {
            	left_pwm = -5*speed_rate * speed_goal  ;       //C  ��ʶ��ֱ�ǵ�ʱ������еı�������
              right_pwm = 1*speed_rate * speed_goal  ;
        }
    }
	if(flag_R_zhi_frc)
    {
			flag_others =1;
        Angle_zhi += imu660ra_gyro_z * timer11 / 65.6;
        if(Angle_zhi <-60)
        {
            flag_R_zhi_frc = 0;
            flag_others=0;
					  Angle_zhi=0;
           	
        }
        else
        {
          left_pwm = 1*speed_rate * speed_goal ;           //C  ��ʶ��ֱ�ǵ�ʱ������еı�������
          right_pwm = -5*speed_rate * speed_goal ;
        }
    }
}
/***********************�۽Ǵ���*************************
��������void zhijiao_handler()
��  �ܣ���ֱ�Ǵ���
��  ������
����ֵ��void
*************************************************************/
void dunjiao_andler()
{
    static uint16 count_delay_dun; 
    if(flag_L_dun_frc)
    {
		    flag_others=1;
        Angle_dun += imu660ra_gyro_z * timer11 / 65.6;
        if(Angle_dun >40)
        {
            flag_L_dun_frc= 0;
            flag_others= 0;
					  Angle_dun=0;
        }
        else
        {
            	left_pwm = -5 *speed_rate * speed_goal  ;
              right_pwm = 1*speed_rate * speed_goal  ;
        }
    }
	if(flag_R_dun_frc)
    {
				flag_others=1;
        Angle_dun += imu660ra_gyro_z * timer11 / 65.6;
        if(Angle_dun <-40)
        {
            flag_R_dun_frc= 0;
            flag_others= 0;
					  Angle_dun=0;
        }
        else
        {
          left_pwm = 1*speed_rate * speed_goal ;
          right_pwm=-5*speed_rate * speed_goal ;
        }
    } 
}
/***********************�ϰ��ﴦ��*************************
��������void block_handler()
��  �ܣ����ϰ��ﴦ��
��  ������
����ֵ��void
*************************************************************/
void block_handler()
{
	  if(flag_block_detected)
    {
        flag_others = 1;
        left_pwm = 2 * 50;
        right_pwm = -1*  50;
        Angle_block += imu660ra_gyro_z * 0.02 / 65.6;
    }
    if(Angle_block < -40)
    {
        
        flag_block_back = 1; 
    }
    if(flag_block_back)
    {
			  Angle_block += imu660ra_gyro_z * 0.02 / 65.6;
        if(Angle_block > 140)
        {
            left_pwm = 1 * 50;
            right_pwm = 0.5 * 50;
  					flag_block_adjust = 1;
					  flag_block_back = 0;
        }
        else
        {
            right_pwm = 2 * 50;
            left_pwm = 0.3 * 50;   
//          right_pwm = 0 * speed_rate * speed_goal*1.5;
//         left_pwm = 0 * speed_rate * speed_goal*1.5;  					

        }       
    }
    if(Angle_block < 100 && Angle_block > -100 && flag_block_adjust)
    {
        flag_others = 0;
        flag_block_detected = 0;
        fang=1;
        flag_block_adjust = 0;
        Angle_block = 0;

    }
}
/***********************���ٶȽ���ѡ����*************************
��������void speed_handler()
��  �ܣ����ٶȽ���ѡ����
��  ������
����ֵ��void
*************************************************************/
void speed_handler()
{
	  float Angle=0;
    if(flag_L_speed_frc==1)  
    {
			   flag_others=1;
			   Angle += imu660ra_gyro_z * 0.002 / 65.6;
			   if(Angle>30)
				 {
				   flag_L_speed_frc=0;
					 flag_others=0;
				 }
				 else
				 {
					 lout=2500;
					 rout=2500;
				 }
		
		}    
		if(flag_R_speed_frc==1) 
    {
				Angle += imu660ra_gyro_z * 0.002 / 65.6;
				flag_others=1;
			   if(Angle>30)
				 {
				   flag_R_speed_frc=0;
					 flag_others=0;
				 }
				 else
				 {
					 lout=2500;
					 rout=2500;
				 }
		}			
}
	
void fork_handler()
{
	
	 if(flag_others==0 &&flag_L_circ_in==0&&left_data<55&&right_data<55&&my_abs(left_data-right_data)<15&&left_dataL>40&&right_dataR>40&&my_abs(left_dataL-right_dataR)<5) // &&left_data<70&&right_data<30
    {
			  left_pwm=6000;
			  right_pwm=6000;
	  }
//    static int16 count_delay_fork = 0;
//    if(flag_fork)
//    {
//        flag_others = 1;
//        pid_motor_L.SetValue = 2 * speed_rate * speed_goal;
//        pid_motor_R.SetValue = 0;
//        Angle_fork += imu660ra_gyro_z * 0.002 / 65.6;
//        if(Angle_fork > 50 || Angle_fork < -50)
//        {
////			Angle_fork=0;
//            flag_fork = 0;
//            flag_fork_adjust = 1;
//        }
//    }
//    if(flag_fork_adjust)
//    {
//        pid_motor_L.SetValue = 0;
//        pid_motor_R.SetValue = 2 * speed_rate * speed_goal;
//        Angle_fork += imu660ra_gyro_z * 0.002 / 65.6;
//        if(Angle_fork < 10 && Angle_fork > -10)
//        {
//            flag_fork_adjust = 0;
//            Angle_fork = 0;
//            flag_fork_in = 1;
//            flag_others = 0;
//        }
//    }
//    if(flag_fork_in)
//    {
//        count_delay_fork++;
//        if(count_delay_fork > 5 * TIM1_ISR_F)
//        {
//            flag_fork_in = 0;
//            count_delay_fork = 0;
//        }
//    }
}

void special_element()
{
	   //imu660ra_get_gyro();
     led_blink(); 	// ����˸��ȷ���ж�����
//	   //circ_handler();
	  // speed_choose();
		// circ_recognition();     // �������µ�ʶ��
//		 zhijiao_recognition();  //ֱ��ʶ��
//	   dunjiao_recognition();
	   HALL_recognition();      //ͣ�����
		 block_recognition();    // �ϰ�ʶ��
		 circ_handler();         //Բ������
		 block_handler();        //���ϴ���
		 zhijiao_handler();     //ֱ�Ǵ���
	   speed_handler();
	   dunjiao_andler();

}
