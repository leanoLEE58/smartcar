#include "fuzzypid.h"
/*
FuzzyPID Fuzzy_PID={0};


//float e_membership_values[7] = {-3,-2,-1,0,1,2,3}; //����e������ֵ
//float ec_membership_values[7] = { -3,-2,-1,0,1,2,3 };//����de/dt������ֵ
//float kp_menbership_values[7] = { -3,-2,-1,0,1,2,3 };//�������kp������ֵ
//float ki_menbership_values[7] = { -3,-2,-1,0,1,2,3 }; //�������ki������ֵ
//float kd_menbership_values[7] = { -3,-2,-1,0,1,2,3 };  //�������kd������ֵ
//float fuzzyoutput_menbership_values[7] = { -3,-2,-1,0,1,2,3 };



//int  Fuzzy_rule_list[7][7] = { {PB,PB,PB,PB,PM,ZO,ZO},  
//															 {PB,PB,PB,PM,PM,ZO,ZO},
//															 {PB,PM,PM,PS1,ZO,NS,NM},
//															 {PM,PM,PS1,ZO,NS,NM,NM},
//															 {PS1,PS1,ZO,NM,NM,NM,NB},
//															 {ZO,ZO,ZO,NM,NB,NB,NB},
//															 {ZO,NS,NB,NB,NB,NB,NB}};


void FuzzyPID_int()  //��ʼ������
{
	  Fuzzy_PID.num_area = 8;
    Fuzzy_PID.kp = 0;
    Fuzzy_PID.ki = 0;
    Fuzzy_PID.kd = 0;
    Fuzzy_PID.fuzzy_output = 0;
    Fuzzy_PID.qdetail_kp = 0;
    Fuzzy_PID.qdetail_ki = 0;
    Fuzzy_PID.qdetail_kd = 0;
    Fuzzy_PID.qfuzzy_output = 0;
    Fuzzy_PID.errosum = 0;
	  Fuzzy_PID.detail_kp=0;                //�������kp
    Fuzzy_PID.detail_ki=0;                //�������ki
    Fuzzy_PID.detail_kd=0;                //�������kd
	  Fuzzy_PID.qerro=0;                    //����e��Ӧ�����е�ֵ
    Fuzzy_PID.qerro_c=0;                  //����de/dt��Ӧ�����е�ֵ
}


//����e��de/dt�����ȼ��㺯��///
void Get_grad_membership(FuzzyPID *FuzzyPID,float erro,float erro_c)  
{
	  int i;
    if (erro > e_membership_values[0] && erro < e_membership_values[6])
    {
        for (i = 0; i < FuzzyPID->num_area - 2; i++)
        {
            if (erro >= e_membership_values[i] && erro <= e_membership_values[i + 1])
            {
                e_gradmembership[0] = -(erro - e_membership_values[i + 1]) / (e_membership_values[i + 1] - e_membership_values[i]);
                e_gradmembership[1] = 1+(erro - e_membership_values[i + 1]) / (e_membership_values[i + 1] - e_membership_values[i]);
                e_grad_index[0] = i;
                e_grad_index[1] = i + 1;
                break;
            }
        }
    }
    else
    {
        if (erro <= e_membership_values[0])
        {
            e_gradmembership[0] = 1;
            e_gradmembership[1] = 0;
            e_grad_index[0] = 0;
            e_grad_index[1] = -1;
        }
        else if (erro >= e_membership_values[6])
        {
            e_gradmembership[0] = 1;
            e_gradmembership[1] = 0;
            e_grad_index[0] = 6;
            e_grad_index[1] = -1;
        }
    }

    if (erro_c > ec_membership_values[0] && erro_c < ec_membership_values[6])
    {
        for (i = 0; i < FuzzyPID->num_area - 2; i++)
        {
            if (erro_c >= ec_membership_values[i] && erro_c <= ec_membership_values[i + 1])
            {
                ec_gradmembership[0] = -(erro_c - ec_membership_values[i + 1]) / (ec_membership_values[i + 1] - ec_membership_values[i]);
                ec_gradmembership[1] = 1 + (erro_c - ec_membership_values[i + 1]) / (ec_membership_values[i + 1] - ec_membership_values[i]);
                ec_grad_index[0] = i;
                ec_grad_index[1] = i + 1;
                break;
            }
        }
    }
    else
    {
        if (erro_c <= ec_membership_values[0])
        {
            ec_gradmembership[0] = 1;
            ec_gradmembership[1] = 0;
            ec_grad_index[0] = 0;
            ec_grad_index[1] = -1;
        }
        else if (erro_c >= ec_membership_values[6])
        {
            ec_gradmembership[0] = 1;
            ec_gradmembership[1] = 0;
            ec_grad_index[0] = 6;
            ec_grad_index[1] = -1;
        }
    }

}
//int  Kp_rule_list[7][7];
//int  Ki_rule_list[7][7];
//int  Kd_rule_list[7][7];

int	  Kp_rule_list[7][7] = {  {PB,PB,PM,PM,PS1,ZO,ZO},     //kp�����
														{PB,PB,PM,PS1,PS1,ZO,NS},
														{PM,PM,PM,PS1,ZO,NS,NS},
														{PM,PM,PS1,ZO,NS,NM,NM},
														{PS1,PS1,ZO,NS,NS,NM,NM},
														{PS1,ZO,NS,NM,NM,NM,NB},
														{ZO,ZO,NM,NM,NM,NB,NB}};
int	  Ki_rule_list[7][7] = { {NB,NB,NM,NM,NS,ZO,ZO},     //ki�����
														{NB,NB,NM,NS,NS,ZO,ZO},
														{NB,NM,NS,NS,ZO,PS1,PS1},
														{NM,NM,NS,ZO,PS1,PM,PM},
														{NM,NS,ZO,PS1,PS1,PM,PB},
														{ZO,ZO,PS1,PS1,PM,PB,PB},
														{ZO,ZO,PS1,PM,PM,PB,PB}};
int		Kd_rule_list[7][7] = { {PS1,NS,NB,NB,NB,NM,PS1},    //kd�����
														{PS1,NS,NB,NM,NM,NS,ZO},
														{ZO,NS,NM,NM,NS,NS,ZO},
														{ZO,NS,NS,NS,NS,NS,ZO},
														{ZO,ZO,ZO,ZO,ZO,ZO,ZO},
														{PB,NS,PS1,PS1,PS1,PS1,PB},
														{PB,PM,PM,PM,PS1,PS1,PB}};
//��ȡ�������kp,ki,kd����������
void GetSumGrad(FuzzyPID *FuzzyPID)
{
	  int i,j,indexKp,indexKi,indexKd;
	
    for (i = 0; i <= FuzzyPID->num_area - 1; i++)
    {
        KpgradSums[i] = 0;
        KigradSums[i] = 0;
        KdgradSums[i] = 0;
    }
  for (i=0;i<2;i++)
  {
      if (e_grad_index[i] == -1)
      {
       continue;
      }
      for (j = 0; j < 2; j++)
      {
          if (ec_grad_index[j] != -1)
          {
              indexKp = Kp_rule_list[e_grad_index[i]][ec_grad_index[j]] + 3;
              indexKi = Ki_rule_list[e_grad_index[i]][ec_grad_index[j]] + 3;
              indexKd = Kd_rule_list[e_grad_index[i]][ec_grad_index[j]] + 3;
              //gradSums[index] = gradSums[index] + (e_gradmembership[i] * ec_gradmembership[j])* Kp_rule_list[e_grad_index[i]][ec_grad_index[j]];
              KpgradSums[indexKp] = KpgradSums[indexKp] + (e_gradmembership[i] * ec_gradmembership[j]);
              KigradSums[indexKi] = KigradSums[indexKi] + (e_gradmembership[i] * ec_gradmembership[j]);
              KdgradSums[indexKd] = KdgradSums[indexKd] + (e_gradmembership[i] * ec_gradmembership[j]);
          }
          else
          {
            continue;
          }
      }
  }
}

//�����������kp,kd,ki��Ӧ����ֵ//
void GetOUT(FuzzyPID * FuzzyPID)
{
	  
	  int i;
    for (i = 0; i < FuzzyPID->num_area - 1; i++)
    {
        FuzzyPID->qdetail_kp += kp_menbership_values[i] * KpgradSums[i];
        FuzzyPID->qdetail_ki += ki_menbership_values[i] * KigradSums[i];
        FuzzyPID->qdetail_kd += kd_menbership_values[i] * KdgradSums[i];
    }
}
//ģ��PID����ʵ�ֺ���
float FuzzyPIDcontroller(FuzzyPID * FuzzyPID,float e_max, float e_min, float ec_max, float ec_min, float kp_max, float kp_min, float erro, float erro_c,float ki_max,float ki_min,float kd_max,float kd_min,float erro_pre,float errp_ppre)
{
	  float output;
    FuzzyPID->errosum += erro;
    //Arear_dipart(e_max, e_min, ec_max, ec_min, kp_max, kp_min,ki_max,ki_min,kd_max,kd_min);
    FuzzyPID->qerro = Quantization(e_max, e_min, erro);
    FuzzyPID->qerro_c = Quantization(ec_max, ec_min, erro_c);
	  
    Get_grad_membership(&Fuzzy_PID,FuzzyPID->qerro, FuzzyPID->qerro_c);
    GetSumGrad(&Fuzzy_PID);
    GetOUT(&Fuzzy_PID);
	  
    FuzzyPID->detail_kp = Inverse_quantization(kp_max, kp_min, FuzzyPID->qdetail_kp);
    FuzzyPID->detail_ki = Inverse_quantization(ki_max, ki_min, FuzzyPID->qdetail_ki);
    FuzzyPID->detail_kd = Inverse_quantization(kd_max, kd_min, FuzzyPID->qdetail_kd);
    FuzzyPID->qdetail_kd = 0;
    FuzzyPID->qdetail_ki = 0;
    FuzzyPID->qdetail_kp = 0;
//    if (qdetail_kp >= kp_max)
//        qdetail_kp = kp_max;
//    else if (qdetail_kp <= kp_min)
//        qdetail_kp = kp_min;
//    if (qdetail_ki >= ki_max)
//        qdetail_ki = ki_max;
//    else if (qdetail_ki <= ki_min)
//        qdetail_ki = ki_min;
//    if (qdetail_kd >= kd_max)
//        qdetail_kd = kd_max;
//    else if (qdetail_kd <= kd_min)
//        qdetail_kd = kd_min;
    FuzzyPID->kp = FuzzyPID->kp + FuzzyPID->detail_kp;
    FuzzyPID->ki = FuzzyPID->ki + FuzzyPID->detail_ki;
    FuzzyPID->kd = FuzzyPID->kd + FuzzyPID->detail_kd;
    if (FuzzyPID->kp < 0)
        FuzzyPID->kp = 0;
    if (FuzzyPID->ki < 0)
        FuzzyPID->ki = 0;
    if (FuzzyPID->kd < 0)
        FuzzyPID->kd = 0;
    FuzzyPID->detail_kp = 0;
    FuzzyPID->detail_ki=0;
    FuzzyPID->detail_kd=0;
    output = FuzzyPID->kp*(erro - erro_pre) + FuzzyPID->ki * erro + FuzzyPID->kd * (erro - 2 * erro_pre + errp_ppre);
    return output;
}

///����ӳ�亯��///
float Quantization(float maximum,float minimum,float x)
{
    float qvalues;
		qvalues= 6.0 *(x-minimum)/(maximum - minimum)-3;
    //float qvalues=6.0*()
    return qvalues;
   
    //qvalues[1] = 3.0 * ecerro / (maximum - minimum);
}

//������ӳ�亯��
float Inverse_quantization(float maximum, float minimum, float qvalues)
{
    float x ;
		x= (maximum - minimum) *(qvalues + 3)/6 + minimum;
    return x;
}
*/
#define PB  6
#define PM  5
#define PS  4
#define ZO  3
#define NS  2
#define NM  1
#define NB  0

float U=0;                            //ƫ��,ƫ��΢���Լ����ֵ�ľ�ȷ��
float PF[2]={0},DF[2]={0},UF[4]={0};  //ƫ��,ƫ��΢���Լ����ֵ��������
int Pn=0,Dn=0,Un[4]={0};
float t1=0,t2=0,t3=0,t4=0,temp1=0,temp2=0;

float Fuzzy_P(int E,int EC)
{
    //������ûʲô���ɣ�pԽ��ת��Խ�ã�ֱ�����ж�����pСת��������ƾ�о���
    //�������õ���pd����������������p�����ʲô��Χ�������p�ͻ��з���
	float EFF[7]={-100,-80,-60,0,60,80,100};//����ͷ������
    //������D����ֵ������
    float DFF[7]={-80,-60,-20,0,20,60,80};//���仯�ʷ���
    //�����U����ֵ������(������������ѡ��ͬ�����ֵ)
    float UFF[7]={0,0.36,0.75,0.996,1.36953,1.7098,2.185};      //�޷�����

	int rule[7][7]={
    //    0   1   2   3   4   5   6
        { 6 , 5 , 4 , 3 , 2 , 1 , 0},//0
        { 5 , 4 , 3 , 2 , 1 , 0 , 1},//1
        { 4 , 3 , 2 , 1 , 0 , 1 , 2},//2
        { 3 , 2 , 1 , 0 , 1 , 2 , 3},//3
        { 2 , 1 , 0 , 1 , 2 , 3 , 4},//4
        { 1 , 0 , 1 , 2 , 3 , 4 , 5},//5
        { 0 , 1 , 2 , 3 , 4 , 5 , 6},//6
    };

    //�����ȵ�ȷ��
    //����PD��ָ������ֵ�����Ч������
    if((E>(*(EFF+0))) && (E<(*(EFF+6))))
    {
        if(E<=((*(EFF+1))))
        {
            Pn=-2;
            *(PF+0)=((*(EFF+1))-E)/((*(EFF+1))-((*(EFF+0))));
        }
        else if(E<=((*(EFF+2))))
        {
            Pn=-1;
            *(PF+0)=((*(EFF+2))-E)/((*(EFF+2))-(*(EFF+1)));
        }
        else if(E<=((*(EFF+3))))
        {
            Pn=0;
            *(PF+0)=((*(EFF+3))-E)/((*(EFF+3))-(*(EFF+2)));
        }
        else if(E<=((*(EFF+4))))
        {
            Pn=1;
            *(PF+0)=((*(EFF+4))-E)/((*(EFF+4))-(*(EFF+3)));
        }
        else if(E<=((*(EFF+5))))
        {
            Pn=2;
            *(PF+0)=((*(EFF+5))-E)/((*(EFF+5))-(*(EFF+4)));
        }
        else if(E<=((*(EFF+6))))
        {
            Pn=3;
            *(PF+0)=((*(EFF+6))-E)/((*(EFF+6))-(*(EFF+5)));
        }
    }

    else if(E<=((*(EFF+0))))
    {
        Pn=-2;
        *(PF+0)=1;
    }
    else if(E>=((*(EFF+6))))
    {
        Pn=3;
        *(PF+0)=0;
    }

   *(PF+1)=1-(*(PF+0));


    //�ж�D��������
    if(EC>(*(DFF+0))&&EC<(*(DFF+6)))
    {
        if(EC<=(*(DFF+1)))
        {
            Dn=-2;
            (*(DF+0))=((*(DFF+1))-EC)/((*(DFF+1))-(*(DFF+0)));
        }
        else if(EC<=(*(DFF+2)))
        {
            Dn=-1;
            (*(DF+0))=((*(DFF+2))-EC)/((*(DFF+2))-(*(DFF+1)));
        }
        else if(EC<=(*(DFF+3)))
        {
            Dn=0;
            (*(DF+0))=((*(DFF+3))-EC)/((*(DFF+3))-(*(DFF+2)));
        }
        else if(EC<=(*(DFF+4)))
        {
            Dn=1;
            (*(DF+0))=((*(DFF+4))-EC)/((*(DFF+4))-(*(DFF+3)));
        }
        else if(EC<=(*(DFF+5)))
        {
            Dn=2;
            (*(DF+0))=((*(DFF+5))-EC)/((*(DFF+5))-(*(DFF+4)));
        }
        else if(EC<=(*(DFF+6)))
        {
            Dn=3;
            (*(DF+0))=((*(DFF+6))-EC)/((*(DFF+6))-(*(DFF+5)));
        }
    }
    //���ڸ�����������
    else if (EC<=(*(DFF+0)))
    {
        Dn=-2;
        (*(DF+0))=1;
    }
    else if(EC>=(*(DFF+6)))
    {
        Dn=3;
        (*(DF+0))=0;
    }

    DF[1]=1-(*(DF+0));

    //ʹ����Χ�Ż���Ĺ����rule[7][7]
    //���ֵʹ��13����������,����ֵ��UFF[7]ָ��
    //һ�㶼���ĸ�������Ч
    Un[0]=rule[Pn+2][Dn+2];
    Un[1]=rule[Pn+3][Dn+2];
    Un[2]=rule[Pn+2][Dn+3];
    Un[3]=rule[Pn+3][Dn+3];

    if((*(PF+0))<=(*(DF+0)))    //��С
        (*(UF+0))=*(PF+0);
    else
        (*(UF+0))=(*(DF+0));
    if((*(PF+1))<=(*(DF+0)))
        (*(UF+1))=*(PF+1);
    else
        (*(UF+1))=(*(DF+0));
    if((*(PF+0))<=DF[1])
        (*(UF+2))=*(PF+0);
    else
        (*(UF+2))=DF[1];
    if((*(PF+1))<=DF[1])
        (*(UF+3))=*(PF+1);
    else
        (*(UF+3))=DF[1];
    //ͬ���������������ֵ���
    if(Un[0]==Un[1])
    {
        if(((*(UF+0)))>((*(UF+1))))
            (*(UF+1))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[0]==Un[2])
    {
        if(((*(UF+0)))>((*(UF+2))))
            (*(UF+2))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[0]==Un[3])
    {
        if((*(UF+0))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[1]==Un[2])
    {
        if((*(UF+1))>(*(UF+2)))
            (*(UF+2))=0;
        else
            (*(UF+1))=0;
    }
    if(Un[1]==Un[3])
    {
        if((*(UF+1))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+1))=0;
    }
    if(Un[2]==Un[3])
    {
        if((*(UF+2))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+2))=0;
    }
    t1=((*(UF+0)))*(*(UFF+(*(Un+0))));
    t2=((*(UF+1)))*(*(UFF+(*(Un+1))));
    t3=((*(UF+2)))*(*(UFF+(*(Un+2))));
    t4=((*(UF+3)))*(*(UFF+(*(Un+3))));
    temp1=t1+t2+t3+t4;
    temp2=(*(UF+0))+(*(UF+1))+(*(UF+2))+(*(UF+3));//ģ�������
    U=temp1/temp2;
    return U;
}
float Fuzzy_D(int  E,int EC)
{
    //������P����ֵ������
    float EFF[7]={-60,-40,12,0,12,25,60};//����ͷ������
    //������D����ֵ������
    float DFF[7]={-40,-20,-7,0,7,20,40}; //���仯�ʷ���
    //�����U����ֵ������(������������ѡ��ͬ�����ֵ)
    float UFF[7]={0,1.5,1.9,2.6,3.9,4.3,5.836};      //�޷�����

    int rule[7][7]={
    //    0  1    2  3    4   5   6
        { 6 , 1 , 2 , 3 , 4 , 5 , 6},//0
        { 1 , 2 , 3 , 4 , 5 , 6 , 5},//1
        { 2 , 3 , 4 , 5 , 6 , 5 , 4},//2
        { 3 , 4 , 5 , 6 , 5 , 4 , 3},//3
        { 4 , 5 , 6 , 5 , 4 , 3 , 2},//4
        { 5 , 6 , 5 , 4 , 3 , 2 , 1},//5
        { 6 , 5 , 4 , 3 , 2 , 1 , 0},//6
    };
    int Pn=0,Dn=0,Un[4]={0};
    //�����ȵ�ȷ��
    //����PD��ָ������ֵ�����Ч������
    if((E>(*(EFF+0))) && (E<(*(EFF+6))))
    {
        if(E<=((*(EFF+1))))
        {
            Pn=-2;
            *(PF+0)=((*(EFF+1))-E)/((*(EFF+1))-(*(EFF+0)));
        }
        else if(E<=((*(EFF+2))))
        {
            Pn=-1;
            *(PF+0)=((*(EFF+2))-E)/((*(EFF+2))-(*(EFF+1)));
        }
        else if(E<=((*(EFF+3))))
        {
            Pn=0;
            *(PF+0)=((*(EFF+3))-E)/((*(EFF+3))-(*(EFF+2)));
        }
        else if(E<=((*(EFF+4))))
        {
            Pn=1;
            *(PF+0)=((*(EFF+4))-E)/((*(EFF+4))-(*(EFF+3)));
        }
        else if(E<=((*(EFF+5))))
        {
            Pn=2;
            *(PF+0)=((*(EFF+5))-E)/((*(EFF+5))-(*(EFF+4)));
        }
        else if(E<=((*(EFF+6))))
        {
            Pn=3;
            *(PF+0)=((*(EFF+6))-E)/((*(EFF+6))-(*(EFF+5)));
        }
    }

    else if(E<=((*(EFF+0))))
    {
        Pn=-2;
        *(PF+0)=1;
    }
    else if(E>=((*(EFF+6))))
    {
        Pn=3;
        *(PF+0)=0;
    }

    *(PF+1)=1-*(PF+0);


    //�ж�D��������
    if(EC>(*(DFF+0))&&EC<(*(DFF+6)))
    {
        if(EC<=(*(DFF+1)))
        {
            Dn=-2;
            (*(DF+0))=((*(DFF+1))-EC)/((*(DFF+1))-(*(DFF+0)));
        }
        else if(EC<=(*(DFF+2)))
        {
            Dn=-1;
            (*(DF+0))=((*(DFF+2))-EC)/((*(DFF+2))-(*(DFF+1)));
        }
        else if(EC<=(*(DFF+3)))
        {
            Dn=0;
            (*(DF+0))=((*(DFF+3))-EC)/((*(DFF+3))-(*(DFF+2)));
        }
        else if(EC<=(*(DFF+4)))
        {
            Dn=1;
            (*(DF+0))=((*(DFF+4))-EC)/((*(DFF+4))-(*(DFF+3)));
        }
        else if(EC<=(*(DFF+5)))
        {
            Dn=2;
            (*(DF+0))=((*(DFF+5))-EC)/((*(DFF+5))-(*(DFF+4)));
        }
        else if(EC<=(*(DFF+6)))
        {
            Dn=3;
            (*(DF+0))=((*(DFF+6))-EC)/((*(DFF+6))-(*(DFF+5)));
        }
    }
    //���ڸ�����������
    else if (EC<=(*(DFF+0)))
    {
        Dn=-2;
        (*(DF+0))=1;
    }
    else if(EC>=(*(DFF+6)))
    {
        Dn=3;
        (*(DF+0))=0;
    }

    DF[1]=1-(*(DF+0));

    //ʹ����Χ�Ż���Ĺ����rule[7][7]
    //���ֵʹ��13����������,����ֵ��UFF[7]ָ��
    //һ�㶼���ĸ�������Ч
    Un[0]=rule[Pn+2][Dn+2];
    Un[1]=rule[Pn+3][Dn+2];
    Un[2]=rule[Pn+2][Dn+3];
    Un[3]=rule[Pn+3][Dn+3];

    if(*(PF+0)<=(*(DF+0)))    //��С
        (*(UF+0))=*(PF+0);
    else
        (*(UF+0))=(*(DF+0));
    if((*(PF+1))<=(*(DF+0)))
        (*(UF+1))=*(PF+1);
    else
        (*(UF+1))=(*(DF+0));
    if(*(PF+0)<=DF[1])
        (*(UF+2))=*(PF+0);
    else
        (*(UF+2))=DF[1];
    if((*(PF+1))<=DF[1])
        (*(UF+3))=*(PF+1);
    else
        (*(UF+3))=DF[1];
    //ͬ���������������ֵ���
    if(Un[0]==Un[1])
    {
        if(((*(UF+0)))>((*(UF+1))))
            (*(UF+1))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[0]==Un[2])
    {
        if((*(UF+0))>(*(UF+2)))
            (*(UF+2))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[0]==Un[3])
    {
        if((*(UF+0))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+0))=0;
    }
    if(Un[1]==Un[2])
    {
        if((*(UF+1))>(*(UF+2)))
            (*(UF+2))=0;
        else
            (*(UF+1))=0;
    }
    if(Un[1]==Un[3])
    {
        if(((*(UF+1)))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+1))=0;
    }
    if(Un[2]==Un[3])
    {
        if((*(UF+2))>(*(UF+3)))
            (*(UF+3))=0;
        else
            (*(UF+2))=0;
    }
    t1=((*(UF+0)))*(*(UFF+(*(Un+0))));
    t2=((*(UF+1)))*(*(UFF+(*(Un+1))));
    t3=((*(UF+2)))*(*(UFF+(*(Un+2))));
    t4=((*(UF+3)))*(*(UFF+(*(Un+3))));
    temp1=t1+t2+t3+t4;
    temp2=(*(UF+0))+(*(UF+1))+(*(UF+2))+(*(UF+3));//ģ�������
    U=temp1/temp2;
    return U;
}
