#ifndef __IMU_H
#define __IMU_H

#include "math.h"
#define	KKp			0.17f		//????
#define	KKi			0.005f	//????
#define	halfT		0.005f	//???????

#define DEG2RAD  	0.017453293f //????p/180 
#define RAD2DEG  	57.29578f    //????180/p 
#define PI				3.141592654f

//?????????????????
typedef struct 
{
	float x;
	float y;
	float z;
}Float_XYZ;


//???????
typedef struct 
{
	float pitch;	//???
	float roll;		//???
	float yaw;		//???
}Float_Angle;

extern Float_Angle Angle;
extern Float_XYZ Acc;
extern Float_XYZ Gyro;

void Get_IMU_Date(Float_XYZ* gyro, Float_XYZ* acc);//??IMU????
void IMU_Update(Float_XYZ* Gyro, Float_XYZ* Acc, Float_Angle* Angle);//????
float abs_jiaoducha(float a,float b);
float jiaoducha(float goal,float yaw);
#endif