//#ifndef __USART_H
//#define __USART_H
//#include "stm32f10x.h"                  // Device header
//#include <stdarg.h>
//#include <stdio.h>

#include "common.h"
#include "zf_uart.h"
/*
#if 1
//#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
typedef struct 
{ 
	int handle; 

}FILE; 

FILE stdout;       
//����sys_exit()�Ա���ʹ�ð�����ģʽ    
void sys_exit(int x) 
{ 
	x = x; 
} 
//�ض���fputc���� 
int fputc(int ch, FILE *f)
{      
	while((USART1->SR&0X40)==0); 
	USART1->DR=(uint8)ch;      
	return ch;
}



#define USART1              ((USART_TypeDef *) USART1_BASE)
#define USART_RCC  RCC_APB2Periph_USART1
#define USART_GPIO_RCC RCC_APB2Periph_GPIOA
#define USART_GPIO GPIOA
#define USART_X    USART1
#define USART_IRQn USART1_IRQn
#define USART_IRQHandler USART1_IRQHandler
#define USART_TX   GPIO_Pin_9
#define USART_RX   GPIO_Pin_10

void Usart_Init(void);
void Send_Byte(uint8 Byte);
void Send_Array(uint8 *Array,uint16 Length);
void Send_String(char*String);
void Send_Number(uint32 Num,uint8 Length);
void Usart_Printf(char *format,...);
uint8 Usart_GetRxFlag(void);
uint8 Usart_GetRxData(void);

uint8 Get_id_Flag(void);//����ȡid_Flag��װ�ɺ���
//float RxPacket_Data_Handle(void);//���ݰ����㴦��*/
//#endif


