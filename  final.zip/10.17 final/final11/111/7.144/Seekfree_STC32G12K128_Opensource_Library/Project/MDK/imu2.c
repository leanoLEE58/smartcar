/********
����������ĸ�ʽΪ����x�����ת���ٶȣ���y��Ľ��ٶȣ���z��Ľ��ٶȣ��ֱ��Ϊroll���ٶȣ�pitch���ٶȺ�yaw���ٶȣ���
���ٶȼ�����ĸ�ʽΪ��x��ļ��ٶȣ�y��ļ��ٶȣ�z��ļ��ٶ�**********/
/********����������gx,gy,gz�����ٶ�����az,ay,az****/
#include "headfile.h"

// imu660ra_gyro_x, imu660ra_gyro_y, imu660ra_gyro_z;      ��������������      gyro (������)
// imu660ra_acc_x, imu660ra_acc_y, imu660ra_acc_z;         ������ٶȼ�����     acc (accelerometer ���ٶȼ�)
//  aacx,aacy,aacz;            ���ٶȴ�����ԭʼ����
//  gyrox,gyroy,gyroz;         ������ԭʼ����

Float_Angle Angle;
Float_XYZ Acc;
Float_XYZ Gyro;

float invSqrt(float x) {
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}

void Get_IMU_Date(Float_XYZ* gyro, Float_XYZ* acc)
{
	short gyrox,gyroy,gyroz;//???????
	short aacx,aacy,aacz;		//??????????
	float alpha = 0.3;
	//??IMU????
	//???????
	gyro->x = imu660ra_gyro_x / 16.4 * PI / 180;	//???????000?s,??????16.4LSB/?s
	gyro->y = imu660ra_gyro_y / 16.4 * PI / 180;	//???????16.4??????,??????????????????
	gyro->z = imu660ra_gyro_z / 16.4 * PI / 180;
	
	//????????
	acc->x = ((float)imu660ra_acc_x* alpha)/ 4096 + acc->x* (1 - alpha);
	acc->y = ((float)imu660ra_acc_y* alpha)/ 4096 + acc->y* (1 - alpha);
	acc->z = ((float)imu660ra_acc_z* alpha)/ 4096 + acc->z* (1 - alpha);
}

/*************************************************
Myhony????
*************************************************/
float q0 = 1, q1 = 0, q2 = 0, q3 = 0;		//???
float exInt = 0, eyInt = 0, ezInt = 0;	//??????

//void IMU_Update(Float_XYZ* Gyro, Float_XYZ* Acc, Float_Angle* Angle)//??IMU?????
void IMU_Update(Float_XYZ* Gyro, Float_XYZ* Acc, Float_Angle* Angle)//??IMU?????,????
{
	float gx = Gyro->x, gy = Gyro->y, gz = Gyro->z;	//?????????,??????
	float ax = Acc->x, ay = Acc->y, az = Acc->z;	//??????????,??????
	float vx, vy, vz;		//??????
	float ex, ey, ez;		//????????????????
	float norm;		//?????
	
	float q0q0 = q0 * q0;
	float q0q1 = q0 * q1;		//????
	float q0q2 = q0 * q2;
	float q0q3 = q0 * q3;
	float q1q1 = q1 * q1;
	float q1q2 = q1 * q2;
	float q1q3 = q1 * q3;
	float q2q2 = q2 * q2;
	float q2q3 = q2 * q3;
	float q3q3 = q3 * q3;
	
	if(Acc->x * Acc->y * Acc->z == 0) // ???????????(??g = 0)???????,?????????????
       return ;
	//???????????(??????)
	norm = invSqrt(ax*ax + ay*ay + az*az);
	ax = ax * norm;
	ay = ay * norm;
	az = az * norm;
	
	//???????????????(??????)  ???v??????
	vx = 2*(q1q3 - q0q2);
	vy = 2*(q0q1 + q2q3);
	vz = q0q0 - q1q1 - q2q2 + q3q3;
	
	//?????????????????????????
	ex = (ay*vz - az*vy);
	ey = (az*vx - ax*vz);
	ez = (ax*vy - ay*vx);
	
	//??????????
	exInt = exInt + ex*halfT;
	eyInt = eyInt + ey*halfT;
	ezInt = ezInt + ez*halfT;
	
	//???PI?????????
	gx =gx + KKp*ex + KKi*exInt;
	gy =gy + KKp*ey + KKi*eyInt;
	gz =gz + KKp*ez + KKi*ezInt;//gz????????????????,????????????(???,??)
	
	//???????
	q0 = q0 + (-q1*gx - q2*gy - q3*gz) * halfT;
	q1 = q1 + (q0*gx + q2*gz - q3*gy) * halfT;
	q2 = q2 + (q0*gy - q1*gz + q3*gx) * halfT;
	q3 = q3 + (q0*gz + q1*gy - q2*gx) * halfT;
	
	//??????(???????)
	norm = invSqrt(q0*q0 + q1*q1 + q2*q2 +q3*q3);
	q0 = q0 * norm;
	q1 = q1 * norm;
	q2 = q2 * norm;
	q3 = q3 * norm;
	
	//?????????
	//Angle->pitch = asin(2.0f * (q1q3 - q0q2)) * RAD2DEG;
	//Angle->roll = atan2(2.0f*q2q3 + 2.0f*q0q1, q0q0 - q1q1- q2q2 + q3q3) * RAD2DEG;
	Angle->yaw = atan2(2.0f*(q1q2 + q0q3), q0q0 + q1q1- q2q2 - q3q3) * RAD2DEG+180;
	
}
float abs_jiaoducha(float a,float b)
{
	if((a-b)>180)
		return 360-a+b;
	if((a-b)<-180)
		return 360+a-b;
	if((a-b)>0)
	return a-b;
	else
		return b-a;
}

float jiaoducha(float goal,float yaw)
{
	float temp,re;
	temp=goal-yaw;
	re=temp;
		if(temp<-180)
			re=360+temp;
		if(temp>180)
			re=-(360-temp);
	return re; 
}